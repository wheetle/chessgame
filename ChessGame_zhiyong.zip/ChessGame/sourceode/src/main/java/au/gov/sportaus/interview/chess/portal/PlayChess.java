/**
 * 
 */
package au.gov.sportaus.interview.chess.portal;

import au.gov.sportaus.interview.chess.board.ChessBoard;
import au.gov.sportaus.interview.chess.utility.ChessLogger;

/**
 * @author Zhiyong Zhang
 *
 */
public class PlayChess {

	private static final ChessBoard board = ChessBoard.getInstance();
	private static final ChessLogger logger = ChessLogger.getInstance();

	
	public static void main (String[] args)
	{
		String[] inputs = {"Queen:D1:3", "Knight:B1:1", "Bishop:C4:4", "Queen:D4:100"};

		for(String input :inputs)
		{
			try {
				logger.info(new StringBuilder("INPUT - ")
										.append(input)
										.append(";	OUTPUT - ")
										.append(board.movePiece(input).toString())
										.toString());
			}catch (Exception e)
			{
				logger.info(e);
			}
		}
	}
}
