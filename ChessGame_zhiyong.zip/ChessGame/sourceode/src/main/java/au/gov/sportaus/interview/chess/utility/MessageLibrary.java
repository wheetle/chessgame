package au.gov.sportaus.interview.chess.utility;

import java.util.Arrays;

public class MessageLibrary {

	public static final String MSG_NULLSTRING = "A NULL string.";
	public static final String MSG_INVLID_MOVE_COMMAND = "Invalid movement command: ";

	private static final String MSG_METHODFAILURE = "Fail to call the method under test: ";
	
	
	private MessageLibrary() {
	}

	public static final String getMessageMethodFailure(String methodName, Exception e)
	{
		StringBuilder build = new StringBuilder(MSG_METHODFAILURE);
		build.append(" '")
				.append(methodName)
				.append("'.\r\n")
				.append(Arrays.toString(e.getStackTrace()));
		
		return build.toString();
	}

	
}
