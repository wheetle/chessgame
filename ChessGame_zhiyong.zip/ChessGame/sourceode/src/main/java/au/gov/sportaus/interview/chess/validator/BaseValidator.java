/**
 * 
 */
package au.gov.sportaus.interview.chess.validator;

/**This is the base class of all the kinds of validator.
 * @author Zhiyong Zhang
 *
 */
public interface BaseValidator {


}
