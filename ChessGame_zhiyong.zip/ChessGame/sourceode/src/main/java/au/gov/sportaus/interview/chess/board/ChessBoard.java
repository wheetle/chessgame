package au.gov.sportaus.interview.chess.board;

import au.gov.sportaus.interview.chess.movement.PiecePosition;
import au.gov.sportaus.interview.chess.piecetype.BasePiece;
import au.gov.sportaus.interview.chess.piecetype.PieceFactory;
import au.gov.sportaus.interview.chess.validator.MoveCommandValidator;
import au.gov.sportaus.interview.chess.validator.ValidatorException;

/** There is only one single instance of this class. Refer to Singleton Pattern.
 * @author Zhiyong Zhang
 *
 */
public class ChessBoard {

	private static final ChessBoard instance = new ChessBoard();
	
	private final Boundary boundary = new Boundary(8, 8);
	
	private MoveCommandValidator commandValidator = MoveCommandValidator.getInstance();
	
	private ChessBoard() {
		
	}
	
	public static ChessBoard getInstance()
	{
		return instance;
	}
	
	public boolean inBoundary(PiecePosition pos)
	{
		return boundary.inBoundary(pos.getAxisX(),  pos.getAxisY());
	}

	private PiecePosition movePiece(String pieceName, String currPos, int steps) throws InstantiationException, IllegalAccessException
	{
		BasePiece piece = PieceFactory.getPiece(pieceName);
		PiecePosition from = new PiecePosition(currPos);
		return piece.move(from,  steps);
		
	}
	
	/**Move a piece to with certain steps. 
	 * @param command The input command should be of the format: <Piece name> : <Current position on board> : <Number of steps>
	 * @return
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 */
	public PiecePosition movePiece(String command) throws ValidatorException, InstantiationException, IllegalAccessException
	{
		commandValidator.validate(command);
		
		String[] args = command.trim().split(":");
		
		String pieceName = args[0];
		String currPos = args[1];
		int steps = Integer.parseInt(args[2]);
		
		return movePiece(pieceName, currPos, steps);
	}
}
