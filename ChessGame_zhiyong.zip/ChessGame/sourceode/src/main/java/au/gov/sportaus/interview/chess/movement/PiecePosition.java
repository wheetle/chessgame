/**
 * 
 */
package au.gov.sportaus.interview.chess.movement;

/**
 * @author Zhiyong Zhang
 *
 */
public class PiecePosition {

	/** x-axis value identified by a value from 1 to 8.*/
	private int xAxis;
	/** y-axis value identified by a value from 1 to 8.*/
	private int yAxis;
	
	/**
	 * 
	 */
	public PiecePosition() {
	}

	public int getAxisX()
	{
		return this.xAxis;
	}
	public int getAxisY()
	{
		return this.yAxis;
	}
	/**
	 * @param x the x-axis value identified by a value from 1 to 8.
	 * @param y the y-axis value identified by a value from 1 to 8.
	 */
	public PiecePosition(int x, int y) {
		this.xAxis = x;
		this.yAxis = y;
	}
	
	/**
	 * @param x the x-axis value identified by a value from 'a' to 'h', case insensitive.
	 * @param y the y-axis value identified by a value from 1 to 8.
	 */
	public PiecePosition(char x, int y) {
		
		x = String.valueOf(x).toLowerCase().charAt(0);
		
		this.xAxis = (int)x - (int)'a' + 1;
		this.yAxis = y;
	}

	/**
	 * @param pos Must be a string with TWO chars, e.g. 'D1'. The first char indicates the x-axis and must be a value from 'a' to 'h' and case insensitive. The second char indicates the y-axis and must be a value from 1 to 8.
	 */
	public PiecePosition(String pos) {
		
		pos = pos.trim();
		char x = pos.toLowerCase().charAt(0);
		int y = Integer.parseInt(pos.substring(1));
		
		this.xAxis = (int)x - (int)'a' + 1;
		this.yAxis = y;
	}
	
	
	public boolean isLegal()
	{
		return true;
	}
	
	public String toString()
	{
		return String.valueOf((char)(xAxis+(int)'a'-1)).toUpperCase() + String.valueOf(yAxis);
	}
	
	public boolean equalsString(String pos)
	{
		if(null == pos)
			return false;
		
		try {
			return this.toString().equalsIgnoreCase(pos.trim());
		}catch(Exception e)
		{
			return false;
		}
	}
}
