/**
 * 
 */
package au.gov.sportaus.interview.chess.piecetype;

/** Refer to Factory Pattern.
 * @author Zhiyong Zhang
 *
 */
public class PieceFactory {

	/**Create a piece instance based on the type provided.
	 * 
	 * @param pieceType A piece type name. 
	 * @return a piece instance.
	 */
	public static BasePiece getPiece(String pieceType)  throws InstantiationException, IllegalAccessException
	{
		return PieceType.getMatchingType(pieceType).getInstance();
	}
	
	 enum PieceType {

		QUEEN(Queen.class),
		BISHOP(Bishop.class),
		KNIGHT(Knight.class),
		NULLTYPE(NullPiece.class);
		
		private Class <? extends BasePiece> pieceClass;
		
		private PieceType(Class <? extends BasePiece> pieceClass) {
			this.pieceClass = pieceClass;
		}
		
		public static PieceType getMatchingType (String enumValue)
		{
			if(null == enumValue)
			{
				return NULLTYPE;
			}
			
			enumValue = enumValue.trim();
			for (PieceType codeName : PieceType.values())
			{
				if(codeName.name().equalsIgnoreCase(enumValue))
				{
					return codeName;
				}
			}
			return NULLTYPE;
		}
		
		public BasePiece getInstance() throws InstantiationException, IllegalAccessException
		{
			return this.pieceClass.newInstance();
		}
	
	}
}
