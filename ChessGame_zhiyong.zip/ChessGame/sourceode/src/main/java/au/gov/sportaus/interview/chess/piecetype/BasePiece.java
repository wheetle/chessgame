package au.gov.sportaus.interview.chess.piecetype;

import au.gov.sportaus.interview.chess.board.ChessBoard;
import au.gov.sportaus.interview.chess.movement.IllegalPosition;
import au.gov.sportaus.interview.chess.movement.MovementRule;
import au.gov.sportaus.interview.chess.movement.PiecePosition;

/**The base class of all the concrete piece classes.
 * @author Zhiyong Zhang
 *
 */
public abstract class BasePiece {

	protected MovementRule mvRule = null;
	
	public PiecePosition move(PiecePosition currPos, int steps)
	{
		PiecePosition from = null;
		PiecePosition to = currPos;
		for(int i=0; i<steps; i++)
		{
			from = to;
			to = mvRule.move(from);
		}
		
		return ChessBoard.getInstance().inBoundary(to)?to:(new IllegalPosition());
	}
	
	public boolean isNull()
	{
		return false;
	}

}
