/**
 * 
 */
package au.gov.sportaus.interview.chess.validator;

import java.util.regex.Pattern;

import au.gov.sportaus.interview.chess.utility.MessageLibrary;

/**This class validates the movement command. There is only one single instance of this class.
 * @author Zhiyong Zhang
 *
 */
public class MoveCommandValidator implements BaseValidator {

	private static final MoveCommandValidator instance = new MoveCommandValidator();

	public static MoveCommandValidator getInstance()
	{
		return instance;
	}

	private MoveCommandValidator() {
		
	}
	
	/**This method uses regular expression to validates that the command string must match the following format '{Piece name} : {Current position on board} : {Number of steps}', 
	 * where the three fields are separated by ':'. 
	 * <li> {Piece name} is a string of alphabet and number combination.
	 * <li> {Current position on board} is a combination of TWO chars, the 1st char is an alphabet and and the 2nd char is a number.
	 * <li> {Number of steps} is an integer value.
	 * 
	 * @param command
	 * @throws ValidatorException
	 */
	public void validate(String command) throws ValidatorException
	{
		if(null == command)
			throw new ValidatorException(MessageLibrary.MSG_NULLSTRING);
		
		String pattern = "(\\w+)(\\s*:\\s*)[A-Za-z][0-9](\\s*:\\s*)(\\d)+";
		
		 boolean isMatch = Pattern.matches(pattern, command.trim());
		 
		 if(!isMatch)
				throw new ValidatorException(MessageLibrary.MSG_INVLID_MOVE_COMMAND + command);
	}

}
