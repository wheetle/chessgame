package au.gov.sportaus.interview.chess.movement;

/**
 * @author Zhiyong Zhang
 *
 */
public enum MovementRule {

	VERTICAL_FORWARD(0, 1), //moves vertically forward 1 place in each step.
	DIAGONAL_RIGHT (1, 1), //moves diagonally right 1 place in each step.
	FRONT2_RIGHT1 (1, 2); //moves 2 steps front and 1 step right in each step.
	
	private int goRight; //the number of steps to go to the right direction.
	private int goFront; //the number of steps to go to the front direction.
	
	MovementRule(int goRight, int goFront)
	{
		this.goRight = goRight;
		this.goFront = goFront;
	}
	
	public PiecePosition move(PiecePosition from)
	{
		return new PiecePosition(from.getAxisX() + this.goRight, from.getAxisY() + this.goFront);
	}

}
