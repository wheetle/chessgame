/**
 * 
 */
package au.gov.sportaus.interview.chess.validator;

import au.gov.sportaus.interview.chess.utility.BaseChessException;

/**
 * @author Zhiyong Zhang
 *
 */
public class ValidatorException extends BaseChessException {

	private static final long serialVersionUID = -4847703954120427988L;

	public ValidatorException(String error)
	{
		super(error);
	}
}
