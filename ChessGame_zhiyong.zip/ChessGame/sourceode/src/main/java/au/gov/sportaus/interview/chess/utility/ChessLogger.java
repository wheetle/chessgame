package au.gov.sportaus.interview.chess.utility;

/**This is the logger class.<br>
 * <b>NOTE:</b> This program does NOT use common logger library (e.g. org.slf4j.Logger, org.slf4j.LoggerFactory) in order to simplify the program and avoid referring external libraries when possible. 
 * @author Zhiyong Zhang
 *
 */

public class ChessLogger {

	private static final ChessLogger instance = new ChessLogger();
	
	private ChessLogger() {
		
	}
	
	public static ChessLogger getInstance()
	{
		return instance;
	}

	public void info(String msg)
	{
		System.out.println(msg);
	}
	public void info(Throwable e)
	{
		e.printStackTrace();
	}
}
