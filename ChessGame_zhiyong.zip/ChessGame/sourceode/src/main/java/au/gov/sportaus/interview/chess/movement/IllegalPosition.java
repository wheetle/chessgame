package au.gov.sportaus.interview.chess.movement;

/** This is an illegal position object. 
 * @author Zhiyong Zhang
 *
 */
public class IllegalPosition extends PiecePosition {


	@Override
	public boolean isLegal()
	{
		return false;
	}
	
	@Override
	public String toString()
	{
		return "Illegal move";
	}

	@Override
	public boolean equalsString(String pos)
	{
		return (null==pos);
	}
}
