package au.gov.sportaus.interview.chess.utility;

/**This is the base class of all the self-defined exceptions in this ChessGame program.
 * 
 * @author Zhiyong Zhang
 *
 */
public class BaseChessException extends Exception {

	private static final long serialVersionUID = -372727451585329214L;

	public BaseChessException() {
	}

	public BaseChessException(String arg0) {
		super(arg0);
	}

	public BaseChessException(Throwable arg0) {
		super(arg0);
		// TODO store the error message of arg0
	}


}
