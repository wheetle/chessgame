package au.gov.sportaus.interview.chess.board;

/** 
 * @author Zhiyong Zhang
 *
 */
public class Boundary {

	
	private int xBoundary;
	private int yBoundary;
	
	public Boundary(int x, int y) {
		xBoundary = x;
		yBoundary = y;
	}
	
	public boolean inBoundary(int xAxis, int yAxis)
	{
		return (xAxis >= 1
					&& xAxis <= xBoundary
					&& yAxis>= 1
					&& yAxis<= yBoundary);
	}


}
