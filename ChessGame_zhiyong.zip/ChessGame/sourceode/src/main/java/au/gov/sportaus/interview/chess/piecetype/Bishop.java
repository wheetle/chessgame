package au.gov.sportaus.interview.chess.piecetype;

import au.gov.sportaus.interview.chess.movement.MovementRule;

/** 
 * @author Zhiyong Zhang
 *
 */
public class Bishop extends BasePiece {

	/**An instance can only be created by {@link au.gov.sportaus.interview.chess.piecetype.PieceFactory#getPiece(java.lang.String)}..
	 */
	protected Bishop() {
		this.mvRule = MovementRule.DIAGONAL_RIGHT;
	}

}
