package au.gov.sportaus.interview.chess.piecetype;

import au.gov.sportaus.interview.chess.movement.IllegalPosition;
import au.gov.sportaus.interview.chess.movement.PiecePosition;

/**  This is a null position object. Refer to Null Object Pattern.
 * @author Zhiyong Zhang
 *
 */
public class NullPiece extends BasePiece  {

	protected NullPiece() {
		this.mvRule = null;
	}

	@Override
	public boolean isNull()
	{
		return true;
	}

	@Override
	public PiecePosition move(PiecePosition currPos, int steps)
	{
		return new IllegalPosition();
	}
	
}
