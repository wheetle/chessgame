/**
 * 
 */
package au.gov.sportaus.interview.chess.test;

import java.util.List;
import java.util.Map;
import java.util.Random;

import org.junit.Assert;
import org.junit.Test;

import com.rmn.pairwise.IInventory;
import com.rmn.pairwise.PairwiseInventoryFactory;

import au.gov.sportaus.interview.chess.board.ChessBoard;
import au.gov.sportaus.interview.chess.movement.PiecePosition;
import au.gov.sportaus.interview.chess.utility.MessageLibrary;

/**This class verifies movements of all the types of pieces: Queen, Bishop and Knight. It also includes negative tests which use illegal piece name and illegal positions as test inputs. Pair-wise approach is used to reduce the size of test input set. Please refer to www.pairwise.org for further details. 
 * @author Zhiyong Zhang
 *
 */
public class ChessBoardTest {

	
	/**
	 * Test method for {@link au.gov.sportaus.interview.chess.board.ChessBoard#getInstance()}.
	 */
	@Test
	public void testGetInstance() {
		Assert.assertNotNull(ChessBoard.getInstance());
	}
	
	/**
	 * Test method for {@link au.gov.sportaus.interview.chess.board.ChessBoard#movePiece(java.lang.String)}.
	 * It verifies movements of a Queen pieces using the complete combination of all the parameter values. There are three parameters: 
	 * <li> xAxis - The x-axis of the current position. The valid value domain is 'a' to 'h' inclusively.
	 * <li> yAxis - The y-axis of the current position. The valid value domain is 1 to 8 inclusively.
	 * <li> steps - The number of steps to move. The value should be between [1, 8], i.e. the maximum steps to move are 8 for a Queen piece. 
	 */
	@Test
	public void testMovePiece_queen() {
		//Create an object to be tested
		ChessBoard board = ChessBoard.getInstance();
		
		//Setup test inputs
		int testIndex = 1;
		for(char xAxis='a'; xAxis<='h'; xAxis++)
		{
			for(int yAxis=1; yAxis<=8; yAxis++)
			{
				//A queen piece can move up to 8 steps.
				for(int steps=1; steps<=8; steps++)
				{
					String input = (new StringBuilder("Queen"))
										.append(":").append(xAxis).append(yAxis)
										.append(":").append(steps)
										.toString();
					
					//Declare the expected values
					String expected = getExpectedDestOfQueen(xAxis, yAxis, steps);
	
					//Call the method under test
					PiecePosition actual = null;
					try {
						actual= board.movePiece(input);
					}catch(Exception e)
					{
						Assert.fail(MessageLibrary.getMessageMethodFailure("movePiece", e));
					}
					
					//Verify the outcome
					
					//-- comment the following statement to improve efficiency of unit tests.
					System.out.println((new StringBuilder())
										.append("Queen test ").append(testIndex++)
										.append(": Input - '").append(input)
										.append("'; Expected output - ").append(expected)		
										.append("; Actual output - ").append(actual.toString())		
										.toString());
					
					Assert.assertTrue(actual.equalsString(expected));
				}
			}
		}
	}

	
	/**
	 * Test method for {@link au.gov.sportaus.interview.chess.board.ChessBoard#movePiece(java.lang.String)}.
	 * It verifies movements of a Bishop pieces using the PAIR-WISE combination of all the parameter values. There are three parameters: 
	 * <li> xAxis - The x-axis of the current position. The valid value domain is 'a' to 'h' inclusively.
	 * <li> yAxis - The y-axis of the current position. The valid value domain is 1 to 8 inclusively.
	 * <li> steps - The number of steps to move. The value should be between [1, 8], i.e. the maximum steps to move are 8 for a Bishop piece.
	 */
	@Test
	public void testMovePiece_bishop() {
		//Create an object to be tested
		ChessBoard board = ChessBoard.getInstance();
		
		//Setup test inputs
		// -- use the PAIR-WISE approach to create a reduced set of  input value combinations. 
		final String inputParameters = (new StringBuilder("paramX: a, b, c, d, e, f, g, h\""))
		        						.append("\nparamY: 1, 2, 3, 4, 5, 6, 7, 8")
		        						.append("\nparamSteps: 1, 2, 3, 4, 5, 6, 7, 8")
		        						.toString();
		
	    IInventory inventory = PairwiseInventoryFactory.generateParameterInventory(inputParameters);
	    List<Map<String, String>> inputDataSet = inventory.getTestDataSet().getTestSets();

		int testIndex = 1;
	    for (Map<String, String> testCase: inputDataSet) {

	        char xAxis = testCase.get("paramX").charAt(0);
	        int yAxis = Integer.parseInt(testCase.get("paramY"));
	        int steps  = Integer.parseInt(testCase.get("paramSteps"));
	        
			String input = (new StringBuilder("Bishop"))
					.append(":").append(xAxis).append(yAxis)
					.append(":").append(steps)
					.toString();
			
			//Declare the expected values
			String expected = getExpectedDestOfBishop(xAxis, yAxis, steps);
			
			//Call the method under test
			PiecePosition actual = null;
			try {
				actual= board.movePiece(input);
			}catch(Exception e)
			{
				Assert.fail(MessageLibrary.getMessageMethodFailure("movePiece", e));
			}
			
			//Verify the outcome
			
			//-- comment the following statement to improve efficiency of unit tests.
			System.out.println((new StringBuilder())
								.append("Bishop test ").append(testIndex++)
								.append(": Input - '").append(input)
								.append("'; Expected output - ").append(expected)		
								.append("; Actual output - ").append(actual.toString())		
								.toString());
							
			Assert.assertTrue(actual.equalsString(expected));
	    }
	}
	
	/**
	 * Test method for {@link au.gov.sportaus.interview.chess.board.ChessBoard#movePiece(java.lang.String)}.
	 * It verifies movements of a Bishop pieces using the PAIR-WISE combination of all the parameter values. There are three parameters: 
	 * <li> xAxis - The x-axis of the current position. The valid value domain is 'a' to 'h' inclusively.
	 * <li> yAxis - The y-axis of the current position. The valid value domain is 1 to 8 inclusively.
	 * <li> steps - The number of steps to move. The value should be between [1, 4], i.e. the maximum steps to move are 4 for a Knight piece.
	 */
	@Test
	public void testMovePiece_knight() {
		//Create an object to be tested
		ChessBoard board = ChessBoard.getInstance();
		
		//Setup test inputs
		// -- use the PAIR-WISE approach to create a reduced set of  input value combinations. 
		final String inputParameters = (new StringBuilder("paramX: a, b, c, d, e, f, g, h\""))
				.append("\nparamY: 1, 2, 3, 4, 5, 6, 7, 8")
				.append("\nparamSteps: 1, 2, 3, 4")
				.toString();
		
	    IInventory inventory = PairwiseInventoryFactory.generateParameterInventory(inputParameters);
	    List<Map<String, String>> inputDataSet = inventory.getTestDataSet().getTestSets();

		int testIndex = 1;
	    for (Map<String, String> testCase: inputDataSet) {

	        char xAxis = testCase.get("paramX").charAt(0);
	        int yAxis = Integer.parseInt(testCase.get("paramY"));
	        int steps  = Integer.parseInt(testCase.get("paramSteps"));
	        
			String input = (new StringBuilder("Knight"))
					.append(":").append(xAxis).append(yAxis)
					.append(":").append(steps)
					.toString();
			
			//Declare the expected values
			String expected = getExpectedDestOfKnight(xAxis, yAxis, steps);

			//Call the method under test
			PiecePosition actual = null;
			try {
				actual= board.movePiece(input);
			}catch(Exception e)
			{
				Assert.fail(MessageLibrary.getMessageMethodFailure("movePiece", e));
			}
			
			//-- comment the following statement to improve efficiency of unit tests.
			System.out.println((new StringBuilder())
								.append("Knight test ").append(testIndex++)
								.append(": Input - '").append(input)
								.append("'; Expected output - ").append(expected)		
								.append("; Actual output - ").append(actual.toString())		
								.toString());
			
			Assert.assertTrue(actual.equalsString(expected));
	    }
	}
	
	/**
	 * Test method for {@link au.gov.sportaus.interview.chess.board.ChessBoard#movePiece(java.lang.String)}.
	 *  The test set guarantees each invalid parameter value is tested for at least one time. There are four parameters:
	 * <li> pieceType - The invalid value domain is {"King", "Unknown"}, which includes unknown piece types.
	 * <li> xAxis - The invalid value domain is {'i', 'z'}, which includes alphabets different from 'a' ~ 'h'.
	 * <li> yAxis - The invalid value domain is { 0, 9}, which includes integer values close to the boundary values.
	 * <li> steps - The invalid value domain is {0, 9}, which includes integer values close to the boundary values.
	 */
	@Test
	public void testMovePiece_negative() {
		//Create an object to be tested
		ChessBoard board = ChessBoard.getInstance();
		
		//Declare the expected values
		String expected = null;
		
		//Setup test inputs
		String[] pieceType = {"King", "Unknown"};
		char[] xAxis = {'i', 'z'};
		int[] yAxis = {0, 9};
		int[] steps = {0, 9};
		
		
		//--Each value of each parameter is verified for one time.
		int testIndex = 1;
		for(int i=0; i<pieceType.length; i++)
		{
			String input = (new StringBuilder(pieceType[i]))
					.append(":").append(xAxis[getRandomInt(xAxis.length)]).append(yAxis[getRandomInt(yAxis.length)])
					.append(":").append(steps[getRandomInt(steps.length)])
					.toString();
			
			runNegativeTest(board, input, expected, testIndex++);
		}
		for(int i=0; i<xAxis.length; i++)
		{
			String input = (new StringBuilder(pieceType[getRandomInt(pieceType.length)]))
					.append(":").append(xAxis[i]).append(yAxis[getRandomInt(yAxis.length)])
					.append(":").append(steps[getRandomInt(steps.length)])
					.toString();
			
			runNegativeTest(board, input, expected, testIndex++);
		}
		for(int i=0; i<yAxis.length; i++)
		{
			String input = (new StringBuilder(pieceType[getRandomInt(pieceType.length)]))
					.append(":").append(xAxis[getRandomInt(xAxis.length)]).append(yAxis[i])
					.append(":").append(steps[getRandomInt(steps.length)])
					.toString();
			
			runNegativeTest(board, input, expected, testIndex++);
		}
		for(int i=0; i<steps.length; i++)
		{
			String input = (new StringBuilder(pieceType[getRandomInt(pieceType.length)]))
					.append(":").append(xAxis[getRandomInt(xAxis.length)]).append(yAxis[getRandomInt(yAxis.length)])
					.append(":").append(steps[i])
					.toString();
			
			runNegativeTest(board, input, expected, testIndex++);
		}
	}	
	
	private void runNegativeTest(ChessBoard board, String input, String expected, int testIndex)
	{
		//Call the method under test
		PiecePosition actual = null;
		try {
			actual= board.movePiece(input);
		}catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail(MessageLibrary.getMessageMethodFailure("movePiece", e));
		}
		
		//Verify the outcome
		
		//-- comment the following statement to improve efficiency of unit tests.
		System.out.println((new StringBuilder())
							.append("Negative test ").append(testIndex++)
							.append(": Input - '").append(input)
							.append("'; Expected output - ").append(expected)		
							.append("; Actual output - ").append(actual.toString())		
							.toString());
		
		Assert.assertTrue(actual.equalsString(expected));
		
	}
	
	/**
	 * @param currX The x-axis of the current position.
	 * @param currY The y-axis of the current position.
	 * @param steps The number of steps to move to.
	 * @return The expected destination of a queen movement.
	 */
	private String getExpectedDestOfQueen(char currX, int currY, int steps)
	{
		if(currY + steps > 8)
		{
			return null;
		}else
		{
			return String.valueOf(currX).toUpperCase() + String.valueOf(currY+steps);
		}
	}

	/**
	 * @param currX The x-axis of the current position.
	 * @param currY The y-axis of the current position.
	 * @param steps The number of steps to move to.
	 * @return The expected destination of a bishop movement.
	 */
	private String getExpectedDestOfBishop(char currX, int currY, int steps)
	{
		if((currY+steps>8) || (currX+steps>'h'))
		{
			return null;
		}else
		{
			return String.valueOf((char)(currX+steps)).toUpperCase() +String.valueOf(currY+steps);
		}
	}
	
	/**
	 * @param currX The x-axis of the current position.
	 * @param currY The y-axis of the current position.
	 * @param steps The number of steps to move to.
	 * @return The expected destination of a bishop movement.
	 */
	private String getExpectedDestOfKnight(char currX, int currY, int steps)
	{
		if((currY+steps*2>8) || (currX+steps>'h'))
		{
			return null;
		}else
		{
			return String.valueOf((char)(currX+steps)).toUpperCase() +String.valueOf(currY+steps*2);
		}
	}
	
	/**
	 * @param max
	 * @return a random integer value between [0, max-1] inclusively..
	 */
	private int getRandomInt(int max)
	{
		return (new Random()).nextInt(max);
	}
	
	
}
