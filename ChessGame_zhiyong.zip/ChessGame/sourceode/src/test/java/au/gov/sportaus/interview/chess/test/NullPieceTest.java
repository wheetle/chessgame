/**
 * 
 */
package au.gov.sportaus.interview.chess.test;

import org.junit.Assert;
import org.junit.Test;

import au.gov.sportaus.interview.chess.movement.IllegalPosition;
import au.gov.sportaus.interview.chess.movement.PiecePosition;
import au.gov.sportaus.interview.chess.piecetype.NullPiece;
import au.gov.sportaus.interview.chess.piecetype.PieceFactory;
import au.gov.sportaus.interview.chess.utility.MessageLibrary;

/**
 * @author Home
 *
 */
public class NullPieceTest {

	/**
	 * Test method for {@link au.gov.sportaus.interview.chess.piecetype.NullPiece#move(au.gov.sportaus.interview.chess.movement.PiecePosition, int)}.
	 */
	@Test
	public void testMove() {
		
		NullPiece nullP = null;
		try {
			nullP = (NullPiece)(PieceFactory.getPiece("null"));
		}catch(Exception e)
		{
			Assert.fail(MessageLibrary.getMessageMethodFailure("NullPiece creation", e));
		}
		for(int x=1; x<=8; x++)
		{
			for(int y=1; y<=8; y++)
			{
				Assert.assertTrue(nullP.move(new PiecePosition(x, y), 1) instanceof IllegalPosition);
			}
		}
	}

	/**
	 * Test method for {@link au.gov.sportaus.interview.chess.piecetype.NullPiece#isNull()}.
	 */
	@Test
	public void testIsNull() {
		NullPiece nullP = null;
		try {
			nullP = (NullPiece)(PieceFactory.getPiece("null"));
		}catch(Exception e)
		{
			Assert.fail(MessageLibrary.getMessageMethodFailure("NullPiece creation", e));
		}
		Assert.assertTrue(nullP.isNull());
	}

}
