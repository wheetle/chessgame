/**
 * 
 */
package au.gov.sportaus.interview.chess.test;

import org.junit.Assert;
import org.junit.Test;

import au.gov.sportaus.interview.chess.movement.IllegalPosition;
import au.gov.sportaus.interview.chess.movement.PiecePosition;

/**
 * @author Home
 *
 */
public class IllegalPositionTest {

	/**
	 * Test method for {@link au.gov.sportaus.interview.chess.movement.IllegalPosition#isLegal()}.
	 */
	@Test
	public void testIsLegal() {
		Assert.assertFalse((new IllegalPosition()).isLegal());
	}

	/**
	 * Test method for {@link au.gov.sportaus.interview.chess.movement.IllegalPosition#equalsString(java.lang.String)}.
	 */
	@Test
	public void testEqualsString() {
		Assert.assertTrue((new IllegalPosition()).equalsString(null));
	}

	/**
	 * Test method for {@link au.gov.sportaus.interview.chess.movement.IllegalPosition#equalsString(java.lang.String)}.
	 */
	@Test
	public void testEqualsString_negative() {
		Assert.assertFalse((new IllegalPosition()).equalsString((new PiecePosition(1, 1)).toString()));
	}

}
