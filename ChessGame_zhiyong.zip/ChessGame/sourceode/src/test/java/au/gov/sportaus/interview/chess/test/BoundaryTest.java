/**
 * 
 */
package au.gov.sportaus.interview.chess.test;

import org.junit.Assert;
import org.junit.Test;

import au.gov.sportaus.interview.chess.board.Boundary;

/**
 * @author Zhiyong Zhang
 *
 */
public class BoundaryTest {


	/**
	 * Test method for {@link au.gov.sportaus.interview.chess.board.Boundary#inBoundary(int, int)}.
	 */
	@Test
	public void testInBoundary() 
	{
		Boundary boundary = new Boundary(8, 8);
		
		int minimum = 1;
		int maximum = 8;
		
		for(int x=minimum; x<=maximum; x++)
		{
			for(int y=minimum; y<=maximum; y++)
			{
				Assert.assertTrue(boundary.inBoundary(x, y));
				
			}
		}
	}

	/**
	 * Test method for {@link au.gov.sportaus.interview.chess.board.ChessBoard#inBoundary(au.gov.sportaus.interview.chess.movement.PiecePosition)}.
	 * To verify a position is out of boundary if the x-axis is out of the boundary.
	 */
	@Test
	public void testInBoundary_negative_x() 
	{
		Boundary boundary = new Boundary(8, 8);
		
		int minimum = 1;
		int maximum = 8;
		
		for(int y=minimum; y<=maximum; y++)
		{
			//set x as a random value larger than the maximum.
			int x = maximum + (int)(Math.random() * 1000);
			Assert.assertFalse(boundary.inBoundary(x, y));
			
			//set x as a random value smaller than the minimum.
			x = -1000 + (int)(Math.random() * (minimum+999));
			Assert.assertFalse(boundary.inBoundary(x, y));
		}
	}
	
	/**
	 * Test method for {@link au.gov.sportaus.interview.chess.board.ChessBoard#inBoundary(au.gov.sportaus.interview.chess.movement.PiecePosition)}.
	 * To verify a position is out of boundary if the y-axis is out of the boundary.
	 */
	@Test
	public void testInBoundary_negative_y() 
	{
		Boundary boundary = new Boundary(8, 8);
		int minimum = 1;
		int maximum = 8;
		
		for(int x=minimum; x<=maximum; x++)
		{
			//set y as a random value larger than the maximum.
			int y = maximum + (int)(Math.random() * 1000);
			Assert.assertFalse(boundary.inBoundary(x, y));
			
			//set y as a random value smaller than the minimum.
			y = -1000 + (int)(Math.random() * (minimum+999));
			Assert.assertFalse(boundary.inBoundary(x, y));
		}
	}

	
}
