/**
 * 
 */
package au.gov.sportaus.interview.chess.test;

import org.junit.Assert;
import org.junit.Test;

import au.gov.sportaus.interview.chess.piecetype.BasePiece;
import au.gov.sportaus.interview.chess.piecetype.Bishop;
import au.gov.sportaus.interview.chess.piecetype.Knight;
import au.gov.sportaus.interview.chess.piecetype.NullPiece;
import au.gov.sportaus.interview.chess.piecetype.PieceFactory;
import au.gov.sportaus.interview.chess.piecetype.Queen;

/**
 * @author Zhiyong Zhang
 *
 */
public class PieceFactoryTest {

	/**
	 * Test method for {@link au.gov.sportaus.interview.chess.piecetype.PieceFactory#getPiece(java.lang.String)}.
	 */
	@Test
	public void testGetPiece_queen() {
		try {
			BasePiece piece = PieceFactory.getPiece("Queen");
			Assert.assertTrue(piece instanceof Queen);
		}catch(Exception e)
		{
			Assert.fail("Fail to create a Queen instance.");
		}
	}
	/**
	 * Test method for {@link au.gov.sportaus.interview.chess.piecetype.PieceFactory#getPiece(java.lang.String)}.
	 */
	@Test
	public void testGetPiece_bishop() {
		try {
			BasePiece piece = PieceFactory.getPiece("bishop");
			Assert.assertTrue(piece instanceof Bishop);
		}catch(Exception e)
		{
			Assert.fail("Fail to create a Bishop instance.");
		}
	}
	
	/**
	 * Test method for {@link au.gov.sportaus.interview.chess.piecetype.PieceFactory#getPiece(java.lang.String)}.
	 */
	@Test
	public void testGetPiece_knight() {
		try {
			BasePiece piece = PieceFactory.getPiece("KNIGHT");
			Assert.assertTrue(piece instanceof Knight);
		}catch(Exception e)
		{
			Assert.fail("Fail to create a Knight instance.");
		}
	}
	
	/**
	 * Test method for {@link au.gov.sportaus.interview.chess.piecetype.PieceFactory#getPiece(java.lang.String)}.
	 */
	@Test
	public void testGetPiece_caseinsensitive() {
		try {
			BasePiece piece = PieceFactory.getPiece("QUEEN");
			Assert.assertTrue(piece instanceof Queen);
			
			piece = PieceFactory.getPiece("queen");
			Assert.assertTrue(piece instanceof Queen);

			piece = PieceFactory.getPiece("quEEn");
			Assert.assertTrue(piece instanceof Queen);
			
		}catch(Exception e)
		{
			Assert.fail("Fail to create a Knight instance.");
		}
	}
	
	/**
	 * Test method for {@link au.gov.sportaus.interview.chess.piecetype.PieceFactory#getPiece(java.lang.String)}.
	 */
	@Test
	public void testGetPiece_trim() {
		try {
			BasePiece piece = PieceFactory.getPiece("Queen  ");
			Assert.assertTrue(piece instanceof Queen);
			
			piece = PieceFactory.getPiece("  Queen");
			Assert.assertTrue(piece instanceof Queen);

			piece = PieceFactory.getPiece("  Queen  ");
			Assert.assertTrue(piece instanceof Queen);
			
			//negative test
			piece = PieceFactory.getPiece("Qu een");
			Assert.assertTrue(piece instanceof NullPiece);
		}catch(Exception e)
		{
			Assert.fail("Fail to create a Knight instance.");
		}
	}
	
	/**
	 * Test method for {@link au.gov.sportaus.interview.chess.piecetype.PieceFactory#getPiece(java.lang.String)}.
	 */
	@Test
	public void testGetPiece_negative_illegalPiece() {
		try {
			BasePiece piece = PieceFactory.getPiece("Unknown");
			Assert.assertTrue(piece instanceof NullPiece);
		}catch(Exception e)
		{
			Assert.fail("Fail to create a Piece instance.");
		}
	}

	/**
	 * Test method for {@link au.gov.sportaus.interview.chess.piecetype.PieceFactory#getPiece(java.lang.String)}.
	 */
	@Test
	public void testGetPiece_negative_blank() {
		try {
			BasePiece piece = PieceFactory.getPiece("    ");
			Assert.assertTrue(piece instanceof NullPiece);
		}catch(Exception e)
		{
			Assert.fail("Fail to create a Piece instance.");
		}
	}

	/**
	 * Test method for {@link au.gov.sportaus.interview.chess.piecetype.PieceFactory#getPiece(java.lang.String)}.
	 */
	@Test
	public void testGetPiece_negative_null() {
		try {
			BasePiece piece = PieceFactory.getPiece(null);
			Assert.assertTrue(piece instanceof NullPiece);
		}catch(Exception e)
		{
			Assert.fail("Fail to create a Piece instance.");
		}
	}
	
}
