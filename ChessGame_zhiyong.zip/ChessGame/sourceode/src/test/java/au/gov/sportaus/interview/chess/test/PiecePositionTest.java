/**
 * 
 */
package au.gov.sportaus.interview.chess.test;

import org.junit.Test;
import org.junit.Assert;

import au.gov.sportaus.interview.chess.movement.PiecePosition;

/**
 * @author Home
 *
 */
public class PiecePositionTest {

	/**
	 * Test method for {@link au.gov.sportaus.interview.chess.movement.PiecePosition#PiecePosition(int, int)}.
	 */
	@Test
	public void testPiecePositionIntInt() {
		
		for(int x=1; x<=8; x++)
		{
			for(int y=1; y<=8; y++)
			{
				PiecePosition pos = new PiecePosition(x, y);
				Assert.assertEquals(x, pos.getAxisX());
				Assert.assertEquals(y, pos.getAxisY());
			}
		}
	}

	/**
	 * Test method for {@link au.gov.sportaus.interview.chess.movement.PiecePosition#PiecePosition(char, int)}.
	 */
	@Test
	public void testPiecePositionCharInt() {
		for(char x='a'; x<='h'; x++)
		{
			for(int y=1; y<=8; y++)
			{
				PiecePosition pos = new PiecePosition(x, y);
				Assert.assertEquals((int)(x-'a'+1), pos.getAxisX());
				Assert.assertEquals(y, pos.getAxisY());
			}
		}
	}

	/**
	 * Test method for {@link au.gov.sportaus.interview.chess.movement.PiecePosition#PiecePosition(java.lang.String)}.
	 */
	@Test
	public void testPiecePositionString() {
		for(char x='A'; x<='H'; x++)
		{
			for(int y=1; y<=8; y++)
			{
				PiecePosition pos = new PiecePosition(x+String.valueOf(y));
				Assert.assertEquals((int)(x-'A'+1), pos.getAxisX());
				Assert.assertEquals(y, pos.getAxisY());
			}
		}
	}

	/**
	 * Test method for {@link au.gov.sportaus.interview.chess.movement.PiecePosition#isLegal()}.
	 */
	@Test
	public void testIsLegal() {
		for(int x=1; x<=8; x++)
		{
			for(int y=1; y<=8; y++)
			{
				Assert.assertTrue((new PiecePosition(x, y)).isLegal());
			}
		}
	}

	/**
	 * Test method for {@link au.gov.sportaus.interview.chess.movement.PiecePosition#toString()}.
	 */
	@Test
	public void testToString() {
		for(char x='a'; x<='h'; x++)
		{
			for(int y=1; y<=8; y++)
			{
				PiecePosition pos = new PiecePosition(x, y);
				String expected = String.valueOf(x).toUpperCase() + y;
				Assert.assertEquals(expected, pos.toString());
			}
		}
	}

	/**
	 * Test method for {@link au.gov.sportaus.interview.chess.movement.PiecePosition#equalsString(java.lang.String)}.
	 */
	@Test
	public void testEqualsString() {
		for(char x='a'; x<='h'; x++)
		{
			for(int y=1; y<=8; y++)
			{
				PiecePosition pos = new PiecePosition(x, y);
				String posString = String.valueOf(x).toUpperCase() + y;
				Assert.assertTrue(pos.equalsString(posString));
			}
		}
	}

	/**
	 * Test method for {@link au.gov.sportaus.interview.chess.movement.PiecePosition#equalsString(java.lang.String)}.
	 */
	@Test
	public void testEqualsString_negative() {
		for(char x='a'; x<='h'; x++)
		{
			for(int y=1; y<=8; y++)
			{
				PiecePosition pos = new PiecePosition(x, y);
				Assert.assertFalse(pos.equalsString(null));
			}
		}
	}
	
}
